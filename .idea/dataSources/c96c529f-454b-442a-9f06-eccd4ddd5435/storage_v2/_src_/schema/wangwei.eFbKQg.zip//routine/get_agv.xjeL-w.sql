create
    definer = root@localhost procedure get_agv(OUT average float)
begin
declare done int default 0;
declare sum_score float default 0.0;
declare temp_score float default 0.0;
declare num int default 0;
declare cur cursor for select score from score;
declare continue handler for not found set done =1;
open cur;
fetch cur into temp_score;
while done =0 do
set sum_score= sum_score+temp_score;
set num=num+1;
fetch cur into temp_score;
end while;
close cur;
set average = sum_score/num;
end;

