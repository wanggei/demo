create
    definer = root@localhost function row_no_fn() returns int
begin
set @row_no = @row_no + 1;
return @row_no;
end;

